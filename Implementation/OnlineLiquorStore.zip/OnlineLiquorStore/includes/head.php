<?php 

	echo '
	
		<link rel="icon" href="view/img/logo-small.png">
		<link rel="stylesheet" type="text/css" href="view/css/style.css">

	';

?>